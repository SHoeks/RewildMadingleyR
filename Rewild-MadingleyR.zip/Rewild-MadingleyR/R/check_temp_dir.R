check_temp_dir = function(){
  system(paste("open",tempdir()))
}